package com.myiptv.app.util;

import android.util.JsonReader;
import android.util.JsonToken;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

/** Streams a big JSON array of flat objects without loading it all in memory. */
public final class JsonRows {
    public interface Row {
        void on(Map<String, String> row);
    }

    private JsonRows() {}

    public static void readArray(InputStream in, Row row) throws IOException {
        JsonReader r = new JsonReader(new InputStreamReader(in, "UTF-8"));
        int count = 0;
        try {
            if (r.peek() != JsonToken.BEGIN_ARRAY) {
                r.skipValue();
                return;
            }
            r.beginArray();
            while (r.hasNext()) {
                if (r.peek() != JsonToken.BEGIN_OBJECT) {
                    r.skipValue();
                    continue;
                }
                Map<String, String> m = new HashMap<>();
                r.beginObject();
                while (r.hasNext()) {
                    String k = r.nextName();
                    JsonToken t = r.peek();
                    if (t == JsonToken.NULL) {
                        r.nextNull();
                    } else if (t == JsonToken.BOOLEAN) {
                        m.put(k, String.valueOf(r.nextBoolean()));
                    } else if (t == JsonToken.STRING || t == JsonToken.NUMBER) {
                        m.put(k, r.nextString());
                    } else {
                        r.skipValue();
                    }
                }
                r.endObject();
                row.on(m);
                count++;
            }
            r.endArray();
        } catch (EOFException e) {
            // an empty response means no rows; a cut-off response is an error
            if (count > 0) throw e;
        } finally {
            r.close();
        }
    }
}
