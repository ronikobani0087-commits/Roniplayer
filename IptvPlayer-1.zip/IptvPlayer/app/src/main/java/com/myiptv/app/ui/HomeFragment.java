package com.myiptv.app.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.SyncRepository;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

public class HomeFragment extends Fragment {
    private TextView status;
    private TextView action;
    private TextView refresh;
    private long activeId = -1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        Context c = requireContext();
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(c, 24);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(c);
        title.setText("الرئيسية");
        title.setTextColor(0xFFD7E6EA);
        title.setTextSize(22);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        root.addView(title);

        status = new TextView(c);
        status.setTextColor(0xFF8FB0B8);
        status.setTextSize(15);
        status.setLineSpacing(0, 1.3f);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = Ui.dp(c, 16);
        root.addView(status, sp);

        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.topMargin = Ui.dp(c, 20);

        action = Ui.button(c, "إضافة قائمة", true);
        action.setOnClickListener(v -> ((MainActivity) requireActivity()).openAddPlaylist());
        row.addView(action);

        refresh = Ui.button(c, "تحديث القائمة", false);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        fp.setMarginStart(Ui.dp(c, 10));
        refresh.setOnClickListener(v -> doRefresh());
        refresh.setVisibility(View.GONE);
        row.addView(refresh, fp);

        root.addView(row, rp);
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        final Context app = requireContext().getApplicationContext();
        Async.io(() -> {
            AppDatabase db = AppDatabase.get(app);
            long id = Prefs.getActive(app);
            Playlist p = id < 0 ? null : db.dao().getPlaylist(id);
            final String text;
            if (p == null) {
                text = "لا توجد قائمة مضافة بعد.\nأضف اشتراكك (Xtream أو M3U) لعرض القنوات والأفلام والمسلسلات.";
            } else {
                text = "القائمة: " + p.name
                        + "\nالقنوات: " + db.dao().countItems(p.id, "live")
                        + "\nالأفلام: " + db.dao().countItems(p.id, "movie")
                        + "\nالمسلسلات: " + db.dao().countItems(p.id, "series");
            }
            final long pid = p == null ? -1 : p.id;
            Async.main(() -> {
                if (!isAdded() || status == null) return;
                activeId = pid;
                status.setText(text);
                refresh.setVisibility(pid < 0 ? View.GONE : View.VISIBLE);
                action.setText(pid < 0 ? "إضافة قائمة" : "إدارة القوائم");
                action.setOnClickListener(v -> {
                    MainActivity a = (MainActivity) requireActivity();
                    if (activeId < 0) a.openAddPlaylist();
                    else a.select(com.myiptv.app.R.id.nav_settings);
                });
            });
        });
    }

    private void doRefresh() {
        if (activeId < 0) return;
        refresh.setEnabled(false);
        SyncRepository.sync(requireContext(), activeId, new SyncRepository.Callback() {
            @Override
            public void onProgress(String message) {
                if (isAdded()) status.setText(message);
            }

            @Override
            public void onDone() {
                if (!isAdded()) return;
                refresh.setEnabled(true);
                load();
            }

            @Override
            public void onError(String message) {
                if (!isAdded()) return;
                refresh.setEnabled(true);
                status.setText("تعذر التحديث: " + message);
            }
        });
    }
}
