package com.myiptv.app.data;

import android.content.Context;

import com.myiptv.app.util.Async;
import com.myiptv.app.util.Http;
import com.myiptv.app.util.JsonRows;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Downloads a playlist (Xtream Codes API or M3U) and stores categories and items in the
 * database exactly in the order the provider returns them. The old data is replaced inside a
 * single transaction, so a failed update never leaves a half-empty playlist.
 */
public final class SyncRepository {
    public interface Callback {
        void onProgress(String message);

        void onDone();

        void onError(String message);
    }

    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final int BATCH = 1000;
    private static final String UNCATEGORIZED = "غير مصنف";
    private static final Pattern ATTR = Pattern.compile("([\\w-]+)=\"([^\"]*)\"");

    private SyncRepository() {}

    public static void sync(Context context, long playlistId, Callback cb) {
        final Context app = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            try {
                AppDatabase db = AppDatabase.get(app);
                Playlist p = db.dao().getPlaylist(playlistId);
                if (p == null) throw new IOException("القائمة غير موجودة");
                if ("xtream".equals(p.type)) {
                    syncXtream(db, p, cb);
                } else {
                    syncM3u(db, p, cb);
                }
                p.updatedAt = System.currentTimeMillis();
                db.dao().updatePlaylist(p);
                Async.main(cb::onDone);
            } catch (Throwable t) {
                Throwable root = (t instanceof RuntimeException && t.getCause() != null) ? t.getCause() : t;
                String m = root.getMessage();
                final String msg = (m == null || m.isEmpty()) ? "تعذر تحديث القائمة" : m;
                Async.main(() -> cb.onError(msg));
            }
        });
    }

    private static void progress(Callback cb, String m) {
        Async.main(() -> cb.onProgress(m));
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private static int next(Map<String, Integer> counters, String key) {
        Integer v = counters.get(key);
        int n = v == null ? 0 : v;
        counters.put(key, n + 1);
        return n;
    }

    // ---------------------------------------------------------------- Xtream

    private static void syncXtream(AppDatabase db, Playlist p, Callback cb) throws Exception {
        final String base = p.url;
        final String uenc = URLEncoder.encode(p.username, "UTF-8");
        final String penc = URLEncoder.encode(p.password, "UTF-8");
        final String api = base + "/player_api.php?username=" + uenc + "&password=" + penc;

        progress(cb, "جارٍ التحقق من الحساب…");
        String info = Http.readString(api);
        JSONObject o;
        try {
            o = new JSONObject(info);
        } catch (JSONException e) {
            throw new IOException("استجابة غير صالحة من السيرفر");
        }
        JSONObject ui = o.optJSONObject("user_info");
        if (ui == null || !"1".equals(ui.optString("auth"))) {
            throw new IOException("بيانات الدخول غير صحيحة");
        }

        final String[] types = {"live", "movie", "series"};
        final String[] catActions = {"get_live_categories", "get_vod_categories", "get_series_categories"};
        final String[] listActions = {"get_live_streams", "get_vod_streams", "get_series"};
        final String[] labels = {"القنوات", "الأفلام", "المسلسلات"};

        db.runInTransaction(() -> {
            try {
                db.dao().deleteCategories(p.id);
                db.dao().deleteItems(p.id);

                for (int t = 0; t < 3; t++) {
                    final String type = types[t];
                    progress(cb, "جارٍ تحميل " + labels[t] + "…");

                    final Set<String> known = new HashSet<>();
                    final List<Category> cats = new ArrayList<>();
                    try (InputStream in = Http.open(api + "&action=" + catActions[t])) {
                        JsonRows.readArray(in, m -> {
                            Category c = new Category();
                            c.playlistId = p.id;
                            c.type = type;
                            c.remoteId = nz(m.get("category_id"));
                            c.name = nz(m.get("category_name"));
                            if (known.add(c.remoteId)) {
                                c.position = cats.size();
                                cats.add(c);
                            }
                        });
                    }

                    final List<Item> buf = new ArrayList<>(BATCH);
                    final Set<String> unknown = new LinkedHashSet<>();
                    final int[] pos = {0};
                    try (InputStream in = Http.open(api + "&action=" + listActions[t])) {
                        JsonRows.readArray(in, m -> {
                            Item it = new Item();
                            it.playlistId = p.id;
                            it.type = type;
                            it.categoryRemoteId = nz(m.get("category_id"));
                            if (!known.contains(it.categoryRemoteId)) unknown.add(it.categoryRemoteId);
                            it.name = nz(m.get("name"));
                            it.rating = nz(m.get("rating"));
                            it.year = nz(m.get("year"));
                            if ("series".equals(type)) {
                                it.remoteId = nz(m.get("series_id"));
                                it.icon = nz(m.get("cover"));
                                it.streamUrl = "";
                            } else if ("live".equals(type)) {
                                it.remoteId = nz(m.get("stream_id"));
                                it.icon = nz(m.get("stream_icon"));
                                it.streamUrl = base + "/live/" + uenc + "/" + penc + "/" + it.remoteId + ".ts";
                            } else {
                                it.remoteId = nz(m.get("stream_id"));
                                it.icon = nz(m.get("stream_icon"));
                                String ext = nz(m.get("container_extension"));
                                if (ext.isEmpty()) ext = "mp4";
                                it.streamUrl = base + "/movie/" + uenc + "/" + penc + "/" + it.remoteId + "." + ext;
                            }
                            it.position = pos[0]++;
                            buf.add(it);
                            if (buf.size() >= BATCH) {
                                db.dao().insertItems(new ArrayList<>(buf));
                                buf.clear();
                            }
                        });
                    }
                    if (!buf.isEmpty()) {
                        db.dao().insertItems(new ArrayList<>(buf));
                        buf.clear();
                    }
                    for (String id : unknown) {
                        Category c = new Category();
                        c.playlistId = p.id;
                        c.type = type;
                        c.remoteId = id;
                        c.name = UNCATEGORIZED;
                        c.position = cats.size();
                        cats.add(c);
                    }
                    if (!cats.isEmpty()) db.dao().insertCategories(cats);
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }

    // ------------------------------------------------------------------- M3U

    private static void syncM3u(AppDatabase db, Playlist p, Callback cb) throws Exception {
        progress(cb, "جارٍ تحميل القائمة…");
        db.runInTransaction(() -> {
            try {
                db.dao().deleteCategories(p.id);
                db.dao().deleteItems(p.id);

                final Map<String, Category> cats = new LinkedHashMap<>();
                final Map<String, Integer> catCount = new HashMap<>();
                final Map<String, Integer> itemCount = new HashMap<>();
                final List<Item> buf = new ArrayList<>(BATCH);
                int total = 0;

                try (InputStream in = Http.open(p.url);
                     BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"), 65536)) {
                    String line;
                    String name = null, logo = null, group = null;
                    while ((line = br.readLine()) != null) {
                        line = line.trim();
                        if (line.isEmpty()) continue;
                        if (line.startsWith("#EXTINF")) {
                            Map<String, String> attrs = attrs(line);
                            logo = attrs.get("tvg-logo");
                            group = attrs.get("group-title");
                            name = extName(line);
                        } else if (line.charAt(0) == '#') {
                            continue;
                        } else {
                            String type = typeOf(line);
                            String g = (group == null || group.trim().isEmpty()) ? UNCATEGORIZED : group.trim();
                            String key = type + "|" + g;
                            if (!cats.containsKey(key)) {
                                Category c = new Category();
                                c.playlistId = p.id;
                                c.type = type;
                                c.remoteId = g;
                                c.name = g;
                                c.position = next(catCount, type);
                                cats.put(key, c);
                            }
                            Item it = new Item();
                            it.playlistId = p.id;
                            it.type = type;
                            it.categoryRemoteId = g;
                            it.position = next(itemCount, type);
                            it.remoteId = String.valueOf(it.position);
                            it.name = (name == null || name.isEmpty()) ? line : name;
                            it.icon = nz(logo);
                            it.streamUrl = line;
                            it.rating = "";
                            it.year = "";
                            buf.add(it);
                            total++;
                            if (buf.size() >= BATCH) {
                                db.dao().insertItems(new ArrayList<>(buf));
                                buf.clear();
                            }
                            name = null;
                            logo = null;
                            group = null;
                        }
                    }
                }
                if (!buf.isEmpty()) db.dao().insertItems(new ArrayList<>(buf));
                if (total == 0) throw new IOException("لم يتم العثور على قنوات في هذا الرابط");
                db.dao().insertCategories(new ArrayList<>(cats.values()));
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }

    private static Map<String, String> attrs(String line) {
        Map<String, String> m = new HashMap<>();
        Matcher mt = ATTR.matcher(line);
        while (mt.find()) {
            m.put(mt.group(1).toLowerCase(Locale.ROOT), mt.group(2));
        }
        return m;
    }

    private static String extName(String line) {
        int q = line.lastIndexOf('"');
        int c = line.indexOf(',', q + 1);
        if (c < 0) return "";
        return line.substring(c + 1).trim();
    }

    private static String typeOf(String url) {
        String l = url.toLowerCase(Locale.ROOT);
        if (l.contains("/movie/")) return "movie";
        if (l.contains("/series/")) return "series";
        return "live";
    }
}
