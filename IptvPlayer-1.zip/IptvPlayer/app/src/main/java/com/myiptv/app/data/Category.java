package com.myiptv.app.data;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "categories",
        indices = {@Index(value = {"playlistId", "type", "position"})})
public class Category {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public long playlistId;
    /** "live", "movie" or "series" */
    public String type;
    public String remoteId;
    public String name;
    /** Order as returned by the provider. */
    public int position;
}
